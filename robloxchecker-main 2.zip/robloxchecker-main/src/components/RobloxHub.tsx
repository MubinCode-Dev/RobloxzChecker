import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { findRobloxProfileByUsername, type RobloxBasicProfile } from "@/lib/roblox-api";

const RobloxHub = () => {
  const [username, setUsername] = useState("");
  const [ripple, setRipple] = useState<{ x: number; y: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<RobloxBasicProfile | null>(null);
  const [error, setError] = useState("");
  const [visitCount, setVisitCount] = useState<number | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const trackVisit = async () => {
      try {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const anonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

        // POST to track visit (deduped by IP), then get count
        const res = await fetch(`${supabaseUrl}/functions/v1/track-visit`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${anonKey}`,
            "apikey": anonKey,
            "Content-Type": "application/json",
          },
        });

        if (res.ok) {
          const data = await res.json();
          setVisitCount(data.count ?? 0);
        }
      } catch {
        // silently fail
      }
    };

    trackVisit();
  }, []);

  const searchProfile = async () => {
    const trimmedUsername = username.trim();

    if (!trimmedUsername) {
      setError("Please enter a username.");
      return;
    }

    setLoading(true);
    setError("");
    setProfile(null);

    try {
      const foundProfile = await findRobloxProfileByUsername(trimmedUsername);

      if (!foundProfile) {
        setError("User not found. Check the exact username and try again.");
        return;
      }

      setProfile(foundProfile);
    } catch {
      setError("Failed to fetch profile. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleClick = async (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setRipple({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    setTimeout(() => setRipple(null), 600);
    await searchProfile();
  };

  const handleConfirm = (confirmed: boolean) => {
    if (confirmed && profile) {
      navigate(`/profile/${profile.id}`, { state: { profile } });
      return;
    }

    setProfile(null);
    setUsername("");
    setError("");
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background px-4">
      {/* Visit counter - top right */}
      {visitCount !== null && (
        <div className="absolute top-4 right-4 z-20 glass-panel px-4 py-2 flex items-center gap-2 animate-fade-in">
          <div className="w-2 h-2 rounded-full bg-neon-green" style={{ animation: "pulse-glow 2s ease-in-out infinite" }} />
          <span className="font-heading text-xs tracking-wider text-muted-foreground uppercase">
            Visits:
          </span>
          <span className="font-heading text-sm font-bold text-neon-cyan neon-text-cyan">
            {visitCount.toLocaleString()}
          </span>
        </div>
      )}

      <div
        className="absolute w-[500px] h-[500px] rounded-full bg-neon-purple/10 blur-[150px]"
        style={{ animation: "ambient-drift 12s ease-in-out infinite", top: "10%", left: "15%" }}
      />
      <div
        className="absolute w-[400px] h-[400px] rounded-full bg-neon-blue/10 blur-[120px]"
        style={{ animation: "ambient-drift 15s ease-in-out infinite 3s", bottom: "10%", right: "10%" }}
      />
      <div
        className="absolute w-[300px] h-[300px] rounded-full bg-neon-pink/8 blur-[100px]"
        style={{ animation: "ambient-drift 10s ease-in-out infinite 5s", top: "50%", right: "40%" }}
      />

      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(hsl(270 80% 60% / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(270 80% 60% / 0.3) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div
        className="glass-panel p-8 sm:p-10 w-full max-w-md animate-scale-in relative z-10"
        style={{ animationDelay: "0.1s" }}
      >
        <div className="flex justify-center mb-6" style={{ animation: "float 4s ease-in-out infinite" }}>
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-neon-purple to-neon-blue neon-glow-purple rotate-6 flex items-center justify-center">
            <div className="w-7 h-7 rounded-md bg-background/80" />
          </div>
        </div>

        <h1 className="font-heading text-2xl sm:text-3xl font-bold text-center mb-2 neon-text-purple bg-gradient-to-r from-neon-purple via-neon-blue to-neon-cyan bg-clip-text text-transparent">
          ROBLOX HUB
        </h1>
        <p className="text-center text-muted-foreground text-sm mb-8 tracking-wide">Put your real username</p>

        {profile && (
          <div className="mb-6 animate-fade-in">
            <div className="glass-panel p-5 flex flex-col items-center gap-4">
              <img
                src={profile.avatarUrl}
                alt={profile.displayName}
                className="w-20 h-20 rounded-full border-2 border-neon-purple/40 neon-glow-purple"
              />
              <div className="text-center">
                <p className="font-heading text-base font-bold text-foreground">{profile.displayName}</p>
                <p className="text-xs text-muted-foreground font-body">@{profile.name}</p>
              </div>
              <p className="font-heading text-sm tracking-wider text-neon-cyan neon-text-cyan">Is this you?</p>
              <div className="flex gap-3 w-full">
                <button
                  onClick={() => handleConfirm(true)}
                  className="flex-1 py-2.5 rounded-xl font-heading text-xs tracking-widest uppercase font-semibold text-primary-foreground bg-gradient-to-r from-neon-green to-neon-cyan transition-all duration-300 hover:scale-[1.03] active:scale-[0.97]"
                >
                  Yes
                </button>
                <button
                  onClick={() => handleConfirm(false)}
                  className="flex-1 py-2.5 rounded-xl font-heading text-xs tracking-widest uppercase font-semibold text-primary-foreground bg-gradient-to-r from-neon-pink to-destructive transition-all duration-300 hover:scale-[1.03] active:scale-[0.97]"
                >
                  No
                </button>
              </div>
            </div>
          </div>
        )}

        {error && <p className="text-center text-destructive text-xs font-heading mb-4 animate-fade-in">{error}</p>}

        {!profile && (
          <>
            <div className="mb-6">
              <label className="block font-heading text-xs tracking-wider text-muted-foreground mb-2 uppercase">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !loading) {
                    void searchProfile();
                  }
                }}
                placeholder="Enter your Roblox username"
                className="w-full px-4 py-3 rounded-xl bg-muted/50 border border-glass-border text-foreground placeholder:text-muted-foreground/50 font-body text-sm focus:outline-none focus:border-neon-purple/50 focus:ring-1 focus:ring-neon-purple/30 transition-all duration-300"
              />
            </div>

            <button
              onClick={handleClick}
              disabled={loading}
              className="relative w-full py-3.5 rounded-xl font-heading text-sm tracking-widest uppercase font-semibold text-primary-foreground bg-gradient-to-r from-neon-purple to-neon-blue overflow-hidden transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60 disabled:pointer-events-none"
            >
              {ripple && (
                <span
                  className="absolute rounded-full bg-foreground/30 animate-ping"
                  style={{
                    left: ripple.x - 10,
                    top: ripple.y - 10,
                    width: 20,
                    height: 20,
                  }}
                />
              )}
              {loading ? "Searching..." : "Launch"}
            </button>
          </>
        )}

        <div className="flex items-center justify-center gap-6 mt-8">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-neon-green" style={{ animation: "pulse-glow 2s ease-in-out infinite" }} />
            <span className="text-xs text-muted-foreground font-body">Online</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-neon-cyan" style={{ animation: "pulse-glow 2s ease-in-out infinite 0.5s" }} />
            <span className="text-xs text-muted-foreground font-body">v2.0.4</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RobloxHub;
