import { useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  getRobloxProfileById,
  getRobloxProfileDetails,
  type RobloxBasicProfile,
  type RobloxProfileDetails,
} from "@/lib/roblox-api";

const ProfilePage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { userId } = useParams();
  const [profile, setProfile] = useState<RobloxProfileDetails | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stateProfile = location.state?.profile as RobloxBasicProfile | undefined;

    const fetchDetails = async () => {
      try {
        let baseProfile = stateProfile;

        if (!baseProfile && userId) {
          const parsedUserId = Number(userId);
          if (!Number.isNaN(parsedUserId)) {
            baseProfile = await getRobloxProfileById(parsedUserId) ?? undefined;
          }
        }

        if (!baseProfile) {
          navigate("/");
          return;
        }

        const details = await getRobloxProfileDetails(baseProfile);
        setProfile(details);
      } finally {
        setLoading(false);
      }
    };

    void fetchDetails();
  }, [location.state, navigate, userId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="font-heading text-sm text-neon-cyan neon-text-cyan tracking-widest animate-pulse">LOADING PROFILE...</p>
      </div>
    );
  }

  if (!profile) return null;

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background px-4">
      <div
        className="absolute w-[500px] h-[500px] rounded-full bg-neon-purple/10 blur-[150px]"
        style={{ animation: "ambient-drift 12s ease-in-out infinite", top: "10%", left: "15%" }}
      />
      <div
        className="absolute w-[400px] h-[400px] rounded-full bg-neon-blue/10 blur-[120px]"
        style={{ animation: "ambient-drift 15s ease-in-out infinite 3s", bottom: "10%", right: "10%" }}
      />

      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(hsl(270 80% 60% / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(270 80% 60% / 0.3) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="glass-panel p-8 sm:p-10 w-full max-w-md relative z-10 animate-scale-in">
        {/* Avatar with float + glow animation */}
        <div
          className="flex justify-center mb-6"
          style={{ animation: "float 4s ease-in-out infinite" }}
        >
          <img
            src={profile.avatarUrl}
            alt={profile.displayName}
            className="w-24 h-24 rounded-full border-2 border-neon-purple/50 neon-glow-purple animate-scale-in"
            style={{ animationDelay: "0.2s", animationFillMode: "both" }}
          />
        </div>

        {/* Display name with staggered fade */}
        <h1
          className="font-heading text-xl sm:text-2xl font-bold text-center mb-1 bg-gradient-to-r from-neon-purple via-neon-blue to-neon-cyan bg-clip-text text-transparent neon-text-purple animate-fade-in"
          style={{ animationDelay: "0.3s", animationFillMode: "both" }}
        >
          {profile.displayName}
        </h1>
        <p
          className="text-center text-muted-foreground text-sm font-body mb-6 animate-fade-in"
          style={{ animationDelay: "0.4s", animationFillMode: "both" }}
        >
          @{profile.name}
        </p>

        {/* Stats with staggered animations */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[
            { label: "Friends", value: profile.friendCount },
            { label: "Followers", value: profile.followerCount },
            { label: "Following", value: profile.followingCount },
          ].map((stat, i) => (
            <div
              key={stat.label}
              className="glass-panel p-3 text-center animate-fade-in"
              style={{ animationDelay: `${0.5 + i * 0.1}s`, animationFillMode: "both" }}
            >
              <p className="font-heading text-lg font-bold text-neon-cyan">{stat.value.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground font-body">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Bio */}
        <div
          className="glass-panel p-4 mb-6 animate-fade-in"
          style={{ animationDelay: "0.8s", animationFillMode: "both" }}
        >
          <p className="text-xs text-muted-foreground font-heading uppercase tracking-wider mb-2">Bio</p>
          <p className="text-sm text-foreground font-body leading-relaxed">{profile.description || "No description"}</p>
        </div>

        {profile.created && (
          <p
            className="text-center text-xs text-muted-foreground font-body mb-6 animate-fade-in"
            style={{ animationDelay: "0.9s", animationFillMode: "both" }}
          >
            Joined {new Date(profile.created).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
          </p>
        )}

        {/* Buttons */}
        <div
          className="flex gap-3 animate-fade-in"
          style={{ animationDelay: "1s", animationFillMode: "both" }}
        >
          <button
            onClick={() => navigate("/")}
            className="flex-1 py-3 rounded-xl font-heading text-xs tracking-widest uppercase font-semibold text-foreground border border-glass-border bg-muted/30 transition-all duration-300 hover:scale-[1.02] hover:border-neon-purple/40"
          >
            Back
          </button>
          <button
            onClick={() => navigate(`/profile/${profile.id}/games`, { state: { profile } })}
            className="flex-1 py-3 rounded-xl font-heading text-xs tracking-widest uppercase font-semibold text-primary-foreground bg-gradient-to-r from-neon-purple to-neon-blue text-center transition-all duration-300 hover:scale-[1.02]"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
