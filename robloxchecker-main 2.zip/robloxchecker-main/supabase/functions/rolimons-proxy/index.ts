const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CollectibleItem {
  assetId: number;
  recentAveragePrice: number;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const userId = url.searchParams.get("userId");

    if (!userId) {
      return new Response(JSON.stringify({ error: "userId required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Step 1: Fetch all collectibles from Roblox inventory (paginated)
    const allItems: CollectibleItem[] = [];
    let cursor: string | null = "";

    while (cursor !== null) {
      const cursorParam = cursor ? `&cursor=${cursor}` : "";
      const inventoryUrl = `https://inventory.roblox.com/v1/users/${userId}/assets/collectibles?sortOrder=Asc&limit=100${cursorParam}`;

      try {
        const res = await fetch(inventoryUrl, {
          headers: { Accept: "application/json" },
        });

        if (!res.ok) {
          console.log(`Inventory fetch failed: ${res.status}`);
          break;
        }

        const data = await res.json();
        if (Array.isArray(data?.data)) {
          for (const item of data.data) {
            allItems.push({
              assetId: item.assetId,
              recentAveragePrice: item.recentAveragePrice ?? 0,
            });
          }
          cursor = data.nextPageCursor ?? null;
        } else {
          break;
        }
      } catch (e) {
        console.log(`Inventory error: ${e.message}`);
        break;
      }
    }

    if (allItems.length === 0) {
      return new Response(JSON.stringify({ rap: 0, value: 0, itemCount: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Step 2: RAP from Roblox data
    const totalRap = allItems.reduce((sum, item) => sum + (item.recentAveragePrice || 0), 0);

    // Step 3: Get Rolimons item details for accurate values
    let totalValue = totalRap;
    try {
      const itemDetailsUrl = "https://www.rolimons.com/itemapi/itemdetails";
      const res = await fetch(itemDetailsUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          Accept: "application/json",
          Referer: "https://www.rolimons.com/",
        },
      });

      if (res.ok) {
        const text = await res.text();
        if (text && !text.startsWith("<!")) {
          const data = JSON.parse(text);
          if (data?.items) {
            let calculatedValue = 0;
            for (const item of allItems) {
              const info = data.items[String(item.assetId)];
              if (info) {
                // info array: [name, acronym, rap, value, defaultValue, demand, trend, projected, hyped, rare]
                const rolimonsValue = info[3];
                calculatedValue += rolimonsValue !== -1 ? rolimonsValue : (item.recentAveragePrice || 0);
              } else {
                calculatedValue += item.recentAveragePrice || 0;
              }
            }
            totalValue = calculatedValue;
          }
        }
      }
    } catch (e) {
      console.log(`Rolimons item details error: ${e.message}`);
      // Value stays as RAP fallback
    }

    return new Response(
      JSON.stringify({
        rap: totalRap,
        value: totalValue,
        itemCount: allItems.length,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
