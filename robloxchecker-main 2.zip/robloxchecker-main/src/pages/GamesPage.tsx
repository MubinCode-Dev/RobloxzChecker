import { useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  getRobloxProfileById,
  type RobloxBasicProfile,
} from "@/lib/roblox-api";


interface PlayerValueData {
  rap: number;
  value: number;
  itemCount: number;
}

const fetchPlayerValue = async (userId: number): Promise<PlayerValueData | null> => {
  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const anonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
    
    const res = await fetch(
      `${supabaseUrl}/functions/v1/rolimons-proxy?userId=${userId}`,
      {
        headers: {
          "Authorization": `Bearer ${anonKey}`,
          "apikey": anonKey,
        },
      }
    );

    if (!res.ok) return null;

    const data = await res.json();

    if (data && typeof data.rap === "number") {
      return {
        rap: data.rap,
        value: data.value ?? data.rap,
        itemCount: data.itemCount ?? 0,
      };
    }

    return null;
  } catch {
    return null;
  }
};

const formatNumber = (n: number) => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
};

const GamesPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { userId } = useParams();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<RobloxBasicProfile | null>(null);
  const [valueData, setValueData] = useState<PlayerValueData | null>(null);

  useEffect(() => {
    const stateProfile = location.state?.profile as RobloxBasicProfile | undefined;

    const fetchData = async () => {
      try {
        let base = stateProfile ?? null;

        if (!base && userId) {
          const parsedId = Number(userId);
          if (!Number.isNaN(parsedId)) {
            base = await getRobloxProfileById(parsedId);
          }
        }

        if (!base) {
          navigate("/");
          return;
        }

        setProfile(base);
        const data = await fetchPlayerValue(base.id);
        setValueData(data);
      } finally {
        setLoading(false);
      }
    };

    void fetchData();
  }, [location.state, navigate, userId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="font-heading text-sm text-neon-cyan neon-text-cyan tracking-widest animate-pulse">LOADING VALUE...</p>
      </div>
    );
  }

  if (!profile) return null;

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background px-4">
      <div
        className="absolute w-[500px] h-[500px] rounded-full bg-neon-purple/10 blur-[150px]"
        style={{ animation: "ambient-drift 12s ease-in-out infinite", top: "10%", left: "15%" }}
      />
      <div
        className="absolute w-[400px] h-[400px] rounded-full bg-neon-blue/10 blur-[120px]"
        style={{ animation: "ambient-drift 15s ease-in-out infinite 3s", bottom: "10%", right: "10%" }}
      />

      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(hsl(270 80% 60% / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(270 80% 60% / 0.3) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="glass-panel p-8 sm:p-10 w-full max-w-md relative z-10 animate-scale-in">
        <div className="flex items-center gap-3 mb-6">
          <img
            src={profile.avatarUrl}
            alt={profile.displayName}
            className="w-12 h-12 rounded-full border-2 border-neon-purple/50"
          />
          <div>
            <h1 className="font-heading text-lg font-bold bg-gradient-to-r from-neon-purple via-neon-blue to-neon-cyan bg-clip-text text-transparent">
              {profile.displayName}
            </h1>
            <p className="text-xs text-muted-foreground font-body">@{profile.name}</p>
          </div>
        </div>

        <h2 className="font-heading text-sm tracking-widest uppercase text-neon-cyan neon-text-cyan mb-5">
          Inventory Value
        </h2>

        {valueData ? (
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-2 gap-3">
              <div className="glass-panel p-5 text-center">
                <p className="text-xs text-muted-foreground font-heading uppercase tracking-wider mb-2">RAP</p>
                <p className="font-heading text-xl font-bold text-neon-green">
                  R$ {formatNumber(valueData.rap)}
                </p>
              </div>
              <div className="glass-panel p-5 text-center">
                <p className="text-xs text-muted-foreground font-heading uppercase tracking-wider mb-2">Value</p>
                <p className="font-heading text-xl font-bold text-neon-cyan">
                  R$ {formatNumber(valueData.value)}
                </p>
              </div>
            </div>

            {valueData.itemCount > 0 && (
              <div className="glass-panel p-4 text-center">
                <p className="text-xs text-muted-foreground font-heading uppercase tracking-wider mb-1">Limited Items</p>
                <p className="font-heading text-lg font-bold text-neon-purple">{valueData.itemCount.toLocaleString()}</p>
              </div>
            )}
          </div>
        ) : (
          <div className="glass-panel p-6 mb-6 text-center">
            <p className="text-sm text-muted-foreground font-body">No limited items found or unable to fetch value data.</p>
          </div>
        )}

        <p className="text-center text-[10px] text-muted-foreground/60 font-body mb-5">
          RAP & Values from Rolimons
        </p>

        <div className="flex gap-3">
          <button
            onClick={() => navigate(`/profile/${profile.id}`, { state: { profile } })}
            className="flex-1 py-3 rounded-xl font-heading text-xs tracking-widest uppercase font-semibold text-foreground border border-glass-border bg-muted/30 transition-all duration-300 hover:scale-[1.02] hover:border-neon-purple/40"
          >
            Back
          </button>
          <button
            onClick={() => navigate("/")}
            className="flex-1 py-3 rounded-xl font-heading text-xs tracking-widest uppercase font-semibold text-primary-foreground bg-gradient-to-r from-neon-purple to-neon-blue transition-all duration-300 hover:scale-[1.02]"
          >
            New Search
          </button>
        </div>
      </div>
    </div>
  );
};

export default GamesPage;
