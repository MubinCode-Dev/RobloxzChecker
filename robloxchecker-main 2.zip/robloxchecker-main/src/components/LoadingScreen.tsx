import { useState, useEffect } from "react";

interface LoadingScreenProps {
  onComplete: () => void;
}

const LoadingScreen = ({ onComplete }: LoadingScreenProps) => {
  const [progress, setProgress] = useState(0);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const durationMs = 3500;
    const fadeDelayMs = 250;
    const completeDelayMs = 600;
    const startTime = performance.now();

    let intervalId: ReturnType<typeof setInterval> | undefined;
    let fadeTimeoutId: ReturnType<typeof setTimeout> | undefined;
    let completeTimeoutId: ReturnType<typeof setTimeout> | undefined;
    let fallbackTimeoutId: ReturnType<typeof setTimeout> | undefined;
    let finished = false;

    const finishLoading = () => {
      if (finished) return;
      finished = true;
      setProgress(100);

      fadeTimeoutId = setTimeout(() => {
        setFading(true);
        completeTimeoutId = setTimeout(onComplete, completeDelayMs);
      }, fadeDelayMs);
    };

    intervalId = setInterval(() => {
      const elapsed = performance.now() - startTime;
      const ratio = Math.min(elapsed / durationMs, 1);
      const eased = 1 - Math.pow(1 - ratio, 3);
      const nextProgress = Math.min(100, Math.floor(eased * 100));

      setProgress((previous) => Math.max(previous, nextProgress));

      if (ratio >= 1) {
        finishLoading();
      }
    }, 50);

    fallbackTimeoutId = setTimeout(finishLoading, durationMs + 1200);

    return () => {
      if (intervalId) clearInterval(intervalId);
      if (fadeTimeoutId) clearTimeout(fadeTimeoutId);
      if (completeTimeoutId) clearTimeout(completeTimeoutId);
      if (fallbackTimeoutId) clearTimeout(fallbackTimeoutId);
    };
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-background transition-opacity duration-600 ${
        fading ? "opacity-0" : "opacity-100"
      }`}
    >
      {/* Ambient lights */}
      <div
        className="absolute w-[400px] h-[400px] rounded-full bg-neon-purple/20 blur-[120px]"
        style={{ animation: "ambient-drift 8s ease-in-out infinite", top: "20%", left: "30%" }}
      />
      <div
        className="absolute w-[300px] h-[300px] rounded-full bg-neon-blue/15 blur-[100px]"
        style={{ animation: "ambient-drift 10s ease-in-out infinite 2s", bottom: "20%", right: "25%" }}
      />

      {/* Spinning Roblox-style logo */}
      <div
        className="relative mb-10"
        style={{ animation: "spin-logo 3s linear infinite" }}
      >
        <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-neon-purple to-neon-blue neon-glow-purple rotate-12 flex items-center justify-center">
          <div className="w-10 h-10 rounded-md bg-background/80" />
        </div>
      </div>

      {/* Loading text */}
      <p
        className="font-heading text-sm tracking-[0.3em] text-neon-cyan mb-8 neon-text-cyan"
        style={{ animation: "loading-text-pulse 2s ease-in-out infinite" }}
      >
        LOADING...
      </p>

      {/* Progress bar */}
      <div className="w-64 h-1.5 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-neon-purple via-neon-blue to-neon-cyan relative transition-all duration-100"
          style={{ width: `${progress}%` }}
        >
          <div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
            style={{ animation: "progress-shimmer 1.5s ease-in-out infinite" }}
          />
        </div>
      </div>

      <p className="mt-4 font-heading text-xs text-muted-foreground tracking-wider">
        {Math.round(progress)}%
      </p>
    </div>
  );
};

export default LoadingScreen;
