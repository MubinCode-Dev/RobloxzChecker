import { useState, useCallback, useRef } from "react";
import LoadingScreen from "@/components/LoadingScreen";
import RobloxHub from "@/components/RobloxHub";

const hasLoaded = { current: false };

const Index = () => {
  const [loading, setLoading] = useState(!hasLoaded.current);

  const handleLoadingComplete = useCallback(() => {
    hasLoaded.current = true;
    setLoading(false);
  }, []);

  return (
    <>
      {loading && <LoadingScreen onComplete={handleLoadingComplete} />}
      {!loading && <RobloxHub />}
    </>
  );
};

export default Index;
