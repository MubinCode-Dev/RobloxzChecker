export interface RobloxBasicProfile {
  id: number;
  name: string;
  displayName: string;
  avatarUrl: string;
}

export interface RobloxProfileDetails extends RobloxBasicProfile {
  description: string;
  created: string;
  friendCount: number;
  followerCount: number;
  followingCount: number;
}

export interface RobloxGameInfo {
  name: string;
  placeId: number;
  universeId?: number;
  thumbnailUrl?: string;
}

interface RobloxSearchUser {
  id: number;
  name: string;
  displayName: string;
}

interface BadgeData {
  id: number;
  name: string;
  awarder?: {
    id: number;
    type: string;
    name: string;
  };
  statistics?: {
    awardedDate?: string;
  };
  created?: string;
  updated?: string;
}

const SEARCH_LIMIT = 100;

const toError = (error: unknown) => (error instanceof Error ? error : new Error("Unknown error"));

const parseJson = <T>(text: string): T => {
  try {
    return JSON.parse(text) as T;
  } catch {
    throw new Error("Invalid response from Roblox service");
  }
};

const fetchJson = async <T>(url: string): Promise<T> => {
  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
    },
  });

  const text = await response.text();

  if (!response.ok) {
    throw new Error(text || `Request failed (${response.status})`);
  }

  return parseJson<T>(text);
};

const getSearchUrls = (username: string) => {
  const encodedUsername = encodeURIComponent(username);
  const searchUrl = `https://users.roblox.com/v1/users/search?keyword=${encodedUsername}&limit=${SEARCH_LIMIT}`;

  return [
    `https://users.roproxy.com/v1/users/search?keyword=${encodedUsername}&limit=${SEARCH_LIMIT}`,
    `https://api.allorigins.win/raw?url=${encodeURIComponent(searchUrl)}`,
  ];
};

const getUserUrls = (userId: number) => {
  const userUrl = `https://users.roblox.com/v1/users/${userId}`;

  return [
    `https://users.roproxy.com/v1/users/${userId}`,
    `https://api.allorigins.win/raw?url=${encodeURIComponent(userUrl)}`,
  ];
};

const getAvatarUrl = async (userId: number) => {
  try {
    const avatarData = await fetchJson<{ data?: Array<{ imageUrl?: string }> }>(
      `https://thumbnails.roproxy.com/v1/users/avatar-headshot?userIds=${userId}&size=150x150&format=Png&isCircular=true`
    );

    return avatarData.data?.[0]?.imageUrl ?? "";
  } catch {
    return "";
  }
};

const exactUsernameMatch = (users: RobloxSearchUser[], username: string) => {
  const normalizedUsername = username.trim().toLowerCase();
  return users.find((user) => user.name?.toLowerCase() === normalizedUsername) ?? null;
};

export const findRobloxProfileByUsername = async (username: string): Promise<RobloxBasicProfile | null> => {
  const trimmed = username.trim();

  if (!trimmed) {
    return null;
  }

  const urls = getSearchUrls(trimmed);
  let sawValidResponse = false;
  let lastError: Error | null = null;

  for (const url of urls) {
    try {
      const data = await fetchJson<{ data?: RobloxSearchUser[] }>(url);

      if (!Array.isArray(data.data)) {
        continue;
      }

      sawValidResponse = true;
      const match = exactUsernameMatch(data.data, trimmed);

      if (!match) {
        continue;
      }

      const avatarUrl = await getAvatarUrl(match.id);

      return {
        id: match.id,
        name: match.name,
        displayName: match.displayName,
        avatarUrl,
      };
    } catch (error) {
      lastError = toError(error);
    }
  }

  if (sawValidResponse) {
    return null;
  }

  throw lastError ?? new Error("Could not reach Roblox service");
};

export const getRobloxProfileById = async (userId: number): Promise<RobloxBasicProfile | null> => {
  const urls = getUserUrls(userId);

  for (const url of urls) {
    try {
      const data = await fetchJson<{ id: number; name: string; displayName: string }>(url);

      if (!data?.id || !data?.name) {
        continue;
      }

      const avatarUrl = await getAvatarUrl(data.id);
      return {
        id: data.id,
        name: data.name,
        displayName: data.displayName,
        avatarUrl,
      };
    } catch {
      // Try next endpoint
    }
  }

  return null;
};

const fetchCount = async (url: string) => {
  try {
    const data = await fetchJson<{ count?: number }>(url);
    return data.count ?? 0;
  } catch {
    return 0;
  }
};

export const getRobloxProfileDetails = async (
  baseProfile: RobloxBasicProfile
): Promise<RobloxProfileDetails> => {
  const [userDetails, friendCount, followerCount, followingCount] = await Promise.all([
    (async () => {
      const urls = getUserUrls(baseProfile.id);

      for (const url of urls) {
        try {
          return await fetchJson<{ description?: string; created?: string }>(url);
        } catch {
          // Try next endpoint
        }
      }

      return { description: "", created: "" };
    })(),
    fetchCount(`https://friends.roproxy.com/v1/users/${baseProfile.id}/friends/count`),
    fetchCount(`https://friends.roproxy.com/v1/users/${baseProfile.id}/followers/count`),
    fetchCount(`https://friends.roproxy.com/v1/users/${baseProfile.id}/followings/count`),
  ]);

  return {
    ...baseProfile,
    description: userDetails.description || "No description",
    created: userDetails.created || "",
    friendCount,
    followerCount,
    followingCount,
  };
};

const getGameThumbnail = async (universeId: number): Promise<string> => {
  try {
    const data = await fetchJson<{ data?: Array<{ imageUrl?: string }> }>(
      `https://thumbnails.roproxy.com/v1/games/icons?universeIds=${universeId}&size=150x150&format=Png&isCircular=false`
    );
    return data.data?.[0]?.imageUrl ?? "";
  } catch {
    return "";
  }
};

const getUniverseDetails = async (universeId: number): Promise<{ name: string } | null> => {
  try {
    const data = await fetchJson<{ data?: Array<{ id: number; name: string }> }>(
      `https://games.roproxy.com/v1/games?universeIds=${universeId}`
    );
    return data.data?.[0] ?? null;
  } catch {
    return null;
  }
};

export const getRobloxGames = async (
  userId: number
): Promise<{ firstGame: RobloxGameInfo | null; lastGame: RobloxGameInfo | null }> => {
  try {
    // Get oldest badges (first game approximation) and newest badges (last played approximation)
    const [oldestBadges, newestBadges] = await Promise.all([
      fetchJson<{ data?: BadgeData[] }>(
        `https://badges.roproxy.com/v1/users/${userId}/badges?limit=10&sortOrder=Asc`
      ).catch(() => ({ data: [] as BadgeData[] })),
      fetchJson<{ data?: BadgeData[] }>(
        `https://badges.roproxy.com/v1/users/${userId}/badges?limit=10&sortOrder=Desc`
      ).catch(() => ({ data: [] as BadgeData[] })),
    ]);

    const extractGame = async (badges: BadgeData[]): Promise<RobloxGameInfo | null> => {
      if (!badges?.length) return null;

      for (const badge of badges) {
        if (badge.awarder?.id && badge.awarder?.name) {
          const universeId = badge.awarder.id;
          const [details, thumbnail] = await Promise.all([
            getUniverseDetails(universeId),
            getGameThumbnail(universeId),
          ]);

          return {
            name: details?.name ?? badge.awarder.name,
            placeId: universeId,
            universeId,
            thumbnailUrl: thumbnail,
          };
        }
      }
      return null;
    };

    const [firstGame, lastGame] = await Promise.all([
      extractGame(oldestBadges.data ?? []),
      extractGame(newestBadges.data ?? []),
    ]);

    return { firstGame, lastGame };
  } catch {
    return { firstGame: null, lastGame: null };
  }
};
